### Testing the Debug Tutorial
Test the [Debugging Tutorial](/docs/system/tutorials/debugtutorial/index.html) by creating Tests from Rule Autopsies. Run the Tests and Test Suite to ensure that the Rules 
work as desired.

For more information on the Test Debugging Tutorial, check out the documentation [here](/docs/system/tutorials/testdebugtutorial/index.html).
