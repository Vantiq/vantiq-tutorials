### Open Inference Tutorial

This project contains the service, source and supporting resources created during the [Open Inference Tutorial](/docs/system/tutorials/openinference/index.html). It demonstrates how to use a Remote source to connect to AI models hosted on an inference server that supports the [Open Inference Protocol](/docs/system/openinference/index.html).