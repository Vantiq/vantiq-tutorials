### Quickstart Tutorial
The Quickstart tutorial walks through using the Design Modeler, a visual IDE tool for building Vantiq systems. It uses the Design Modeler's AI Design Assistant, a UI that allows the user to enter a text description of the system to be built then uses Generative AI to turn that description into the beginnings of the running application. 

For more information on the Quickstart Tutorial, please see the documentation [here](/docs/system/tutorials/quickstart.md).
