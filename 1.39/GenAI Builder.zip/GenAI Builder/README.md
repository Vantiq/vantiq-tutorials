### GenAI Builder Tutorial

This project contains the service and supporting resources created during the [GenAI Builder Tutorial](/docs/system/tutorials/genaibuilder.md).  It demonstrates how to use the [Gen AI Builder](/docs/system/genaibuilder.md) to construct custom GenAI functionality for your applications.
