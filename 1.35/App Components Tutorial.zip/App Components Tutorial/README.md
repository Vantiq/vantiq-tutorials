### App Components Tutorial
Improve upon the Design Model created in the [Introductory Tutorial](/docs/system/tutorials/tutorial/index.html) by commonizing tasks from one of the Event Handlers into an App Component.

For more information on the App Components Tutorial, please see the documentation [here](/docs/system/tutorials/componenttutorial/index.html).
