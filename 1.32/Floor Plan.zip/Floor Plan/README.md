### Floor Plan Tutorial
The Floor Plan demonstrates how to place pins in a floor plan in a VANTIQ Client and update the locations of the pins based
on a real time stream of data.

For more information on the Floor Plan Tutorial, check out the documentation [here](/docs/system/tutorials/imagemaptutorial/index.html).
