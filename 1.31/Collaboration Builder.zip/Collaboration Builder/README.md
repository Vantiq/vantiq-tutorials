### Collaboration Builder Tutorial
The Collaboration Builder Tutorial walks through the creation of a collaboration to monitor a patients vital signs. This
tutorial demonstrates how to integrate a VANTIQ application with the VANTIQ mobile app and shows how to send push notifications
to a user's mobile device.

For more information on the Collaboration Builder Tutorial, check out the documentation [here](/docs/system/tutorials/collaboration/index.html).
