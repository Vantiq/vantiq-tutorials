### Debugging VANTIQ Applications
The Debugging Tutorial walks through how to use the autopsy tool to step through the execution of a procedure or rule
and inspect the state of variables at every step along the way.

For more information on the Debugging Tutorial, check out the documentation [here](/docs/system/tutorials/debugtutorial/index.html).
