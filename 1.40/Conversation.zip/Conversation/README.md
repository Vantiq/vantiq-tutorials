### Conversation Widget Tutorial
The Conversation Widget Tutorial demonstrates how to use a Client Conversation Widget. The Conversation Widget adds chat-like generative AI features to Vantiq Clients.

For more information on the Conversation Widget Tutorial, see the documentation [here](/docs/system/tutorials/conversationtutorial/index.html).