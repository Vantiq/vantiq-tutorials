### System Modeler Tutorial
The System Modeler Tutorial contains two projects: Pothole, which contains the System Model described in the Tutorial,
and PotholeReporter, which contains a finished application generated from the System Model in Pothole and modified
based on the instructions in the Tutorial.

For more information on the System Modeler Tutorial, please see the documentation [here](/docs/system/tutorials/systemmod/index.html).
