### Testing the Source Tutorial
Test the [Source Tutorial](/docs/system/tutorials/sourcetutorial/index.html) by create Unit Tests for the weatherReading Rule.
Learn about Source Mocking for both querying from a Source and receiving Source messages.

For more information on the Testing The Source Tutorial, check out the documentation [here](/docs/system/tutorials/testsourcetutorial/index.html).
