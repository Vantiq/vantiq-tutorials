### Client Builder Tutorial
The Client Builder Tutorial demonstrates some of the basic features of the Client Builder by walking through the construction
of a simple client that can submit invoices and aggregate past invoices to compute overall expenses.

For more information on the Client Builder Tutorial, check out the documentation [here](/docs/system/tutorials/client/index.html).
