### App Service Tutorial

The Using App Services Tutorial walks through the modification of the App built during the Introductory Tutorial.  In this tutorial we will learn how to use the App Service and Service Event Types to decouple the Client from the App.  Once that it done we will modify the implementation of the App to show that this can be done without having to make any Client changes.

For more information on the App Service Tutorial, check out the documentation [here](/docs/system/tutorials/appservices.md).
